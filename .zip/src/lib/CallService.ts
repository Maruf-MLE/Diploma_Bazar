import { supabase } from './supabase';
import { io, Socket } from 'socket.io-client';
import { User } from '@supabase/supabase-js';

// Call types and interfaces (kept for compatibility)
export type CallType = 'audio' | 'video';

export interface Call {
  id: string;
  callerId: string;
  receiverId: string;
  startTime?: Date;
  endTime?: Date;
  status: 'initiated' | 'ringing' | 'connected' | 'missed' | 'rejected' | 'ended' | 'failed';
  callType: CallType;
  callerName?: string;
  callerAvatar?: string;
  receiverName?: string;
  receiverAvatar?: string;
  durationSeconds?: number;
}

export interface CallHistoryItem {
  id: string;
  caller_id: string;
  receiver_id: string;
  start_time: string | null;
  end_time: string | null;
  status: string;
  call_type: CallType;
  created_at: string;
  caller_profile?: {
    name: string;
    avatar_url: string | null;
  };
  receiver_profile?: {
    name: string;
    avatar_url: string | null;
  };
  durationSeconds?: number;
}

// Create (or reuse) a singleton Socket.IO client
let socket: Socket | null = null;

const getSocket = () => {
  if (socket) return socket;
  const url = (import.meta as any).env?.VITE_SOCKET_URL || (typeof process !== 'undefined' ? (process.env.NEXT_PUBLIC_SOCKET_URL || process.env.VITE_SOCKET_URL) : '');
  if (!url) {
    console.warn('Socket URL not set. Please define NEXT_PUBLIC_SOCKET_URL in env.');
  }
  // Allow both polling and websocket so that the client can fall back if direct
  // websocket upgrade fails (common on some PaaS like Render)
  socket = io(url, {
    transports: ['websocket'], // disable HTTP polling to avoid xhr poll error
    withCredentials: true
  });

  // Verbose logging – added once per session for easier debugging
  if (!(socket as any)._loggingAdded) {
    (socket as any)._loggingAdded = true;
    socket.on('connect', () => console.log('[Socket] connected', socket.id));
    socket.on('connect_error', (err) => console.error('[Socket] connect_error:', err.message, err));
    socket.on('disconnect', (reason) => console.warn('[Socket] disconnected:', reason));
    socket.on('reconnect_attempt', () => console.log('[Socket] reconnect_attempt'));
    socket.on('reconnect_failed', () => console.error('[Socket] reconnect_failed'));
  }

  return socket;
};

// Call events
export type CallEventTypes =
  | 'incoming_call'
  | 'call_accepted'
  | 'call_rejected'
  | 'call_ended'
  | 'call_error';

/**
 * Initialize call service - simplified version
 */
export const initCallService = async (user: User) => {
  try {
    const s = getSocket();
    // authenticate or join personal room if needed
    s.emit('init', { userId: user.id, name: user.email });
    return true;
  } catch (e) {
    console.error('CallService init error', e);
    return false;
  }
};

/**
 * Create a new call - disabled
 */
export const initiateCall = async (receiverId: string, callType: CallType): Promise<Call | null> => {
  try {
    const callerId = (await supabase.auth.getUser()).data.user?.id;
    if (!callerId) throw new Error('Not authenticated');

    const newCall: Call = {
      id: Math.random().toString(36).substring(2),
      callerId,
      receiverId,
      status: 'initiated',
      callType,
      startTime: new Date()
    };

    const s = getSocket();
    s.emit('start-call', { ...newCall });
    return newCall;
  } catch (e) {
    console.error('initiateCall error', e);
    return null;
  }
};

/**
 * Accept an incoming call - disabled
 */
export const acceptCall = async (callId: string, callerId: string, callType: CallType): Promise<boolean> => {
  try {
    const s = getSocket();
    s.emit('accept-call', { callId, callerId, callType });
    return true;
  } catch (e) {
    console.error('acceptCall error', e);
    return false;
  }
};

/**
 * Reject an incoming call - disabled
 */
export const rejectCall = (callId: string, reason?: string): void => {
  try {
    const s = getSocket();
    s.emit('reject-call', { callId, reason });
  } catch (e) {
    console.error('rejectCall error', e);
  }
};

/**
 * End the current call - disabled
 */
export const endCall = (callId: string, otherPartyId: string): void => {
  try {
    const s = getSocket();
    s.emit('end-call', { callId, otherPartyId });
  } catch (e) {
    console.error('endCall error', e);
  }
};

/**
 * Get the local media stream - disabled
 */
export const getLocalStream = (): MediaStream | null => {
  return null;
};

/**
 * Get the remote media stream - disabled
 */
export const getRemoteStream = (): MediaStream | null => {
  return null;
};

/**
 * Get the current call information - disabled
 */
export const getCurrentCall = (): Call | null => {
  return null;
};

/**
 * Add an event listener - disabled
 */
export const addCallEventListener = (event: CallEventTypes, callback: (data: any) => void): void => {
  const s = getSocket();
  s.on(event, callback);
};

/**
 * Remove an event listener - disabled
 */
export const removeCallEventListener = (event: CallEventTypes, callback: (data: any) => void): void => {
  const s = getSocket();
  s.off(event, callback);
};

/**
 * Generate offer for peer connection - disabled
 */
export const createOffer = async (): Promise<RTCSessionDescriptionInit | null> => {
  console.log('Call feature disabled');
  return null;
};

/**
 * Get call history for current user - simplified to use only Supabase
 */
export const getCallHistory = async (limit = 50): Promise<CallHistoryItem[]> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      throw new Error('Not authenticated');
    }

    const { data, error } = await supabase
      .from('calls')
      .select(`
        id,
        caller_id,
        receiver_id,
        start_time,
        end_time,
        status,
        call_type,
        created_at
      `)
      .or(`caller_id.eq.${user.id},receiver_id.eq.${user.id}`)
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) {
      console.error('Error fetching call history:', error);
      return [];
    }

    if (!data || data.length === 0) {
      return [];
    }

    // Fetch user profiles for caller and receiver
    const uniqueUserIds = new Set<string>();
    data.forEach((call: any) => {
      uniqueUserIds.add(call.caller_id);
      uniqueUserIds.add(call.receiver_id);
    });

    const userIds = Array.from(uniqueUserIds);
    const { data: profiles } = await supabase
      .from('profiles')
      .select('id, name, avatar_url')
      .in('id', userIds);

    const userProfiles = profiles?.reduce((acc: any, profile: any) => {
      acc[profile.id] = profile;
      return acc;
    }, {}) || {};

    // Add profile data and calculate duration
    return data.map((call: any) => {
      const startTime = call.start_time ? new Date(call.start_time) : null;
      const endTime = call.end_time ? new Date(call.end_time) : null;

      const durationSeconds = startTime && endTime 
        ? Math.round((endTime.getTime() - startTime.getTime()) / 1000) 
        : 0;

      return {
        ...call,
        caller_profile: userProfiles[call.caller_id],
        receiver_profile: userProfiles[call.receiver_id],
        durationSeconds
      };
    });
  } catch (error) {
    console.error('Error fetching call history:', error);
    return [];
  }
};

/**
 * Clean up resources - simplified
 */
export const disconnectCallService = (): void => {
  console.log('Call service cleanup completed');
};
